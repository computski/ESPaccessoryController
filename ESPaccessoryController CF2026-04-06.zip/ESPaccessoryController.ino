// Visual Micro is in vMicro>General>Tutorial Mode
// 
/*
    Name:       ESPaccessoryController.ino
    Created:	23/03/2026 11:04:35 PM
    Author:     Julian Ossowski
    Target HW:  NodeMCU 12E
*/


//#include <WiFi.h>
//#include <WiFiClient.h>
//#include <WiFiServer.h>
//#include <WiFiUdp.h>
//#include <dummy.h>
//#include <SocketIOclient.h>  //added 2024-11-26, also updated library to ver 2.6.1 from 2.4.0
//#include <WebSockets.h>
//#include <WebSockets4WebServer.h>
//#include <WebSocketsClient.h>
//#include <WebSocketsServer.h>
//#include <WebSocketsVersion.h>
//#include <ArduinoJson.h>
//#include <ArduinoJson.hpp>
//#include <tcp_axtls.h>
//#include <SyncClient.h>
//#include <ESPAsyncTCPbuffer.h>
//#include <DebugPrintMacros.h>
//#include <async_config.h>
//#include <AsyncPrinter.h>

#include <ESP8266WiFi.h>
#include <ESPAsyncTCP.h>  //Github me-no-dev/ESPAsyncTCP
#include <string>   //required if you wish to compile in arduino IDE, this is the std::string library
#include <EEPROM.h>
#include <stdint.h>
//#include <Wire.h>




// Define User Types below here or use a .h file
//

// Replace with your network credentials
/*
const char* ssid = "Ossonet";
const char* password = "11223344AA";
const char* host = "192.168.1.118"; // Server IP
const int port = 1234;
*/
//https://www.google.com/search?q=esp+AsyncClient+connect+example&sca_esv=37e421cff93e3de4&rlz=1C1CHBF_enAU1138AU1138&sxsrf=ANbL-n51ObJAaQvbTrvhy4vroQSa98Ew0g%3A1774269085621&ei=nTLBac23Jb_h0-kPod6b0AQ&biw=1920&bih=911&ved=0ahUKEwiN-tW0g7aTAxW_8DQHHSHvBkoQ4dUDCBE&uact=5&oq=esp+AsyncClient+connect+example&gs_lp=Egxnd3Mtd2l6LXNlcnAiH2VzcCBBc3luY0NsaWVudCBjb25uZWN0IGV4YW1wbGUyBxAhGKABGApIg54VUJbnFFiGnBVwAngBkAEAmAH8AqAB6CaqAQgwLjIuMTYuMrgBA8gBAPgBAfgBApgCFqACvSfCAgoQABiwAxjWBBhHwgIEECMYJ8ICChAAGIAEGEMYigXCAgsQABiABBiRAhiKBcICCxAuGIAEGLEDGIMBwgIREC4YgAQYsQMY0QMYgwEYxwHCAgsQABiABBixAxiDAcICDhAuGIAEGLEDGIMBGIoFwgIIEAAYgAQYsQPCAgUQLhiABMICFhAuGIAEGLEDGNEDGEMYgwEYxwEYigXCAhMQLhiABBixAxjRAxhDGMcBGIoFwgIFECEYnwXCAgYQABgWGB7CAgsQABiABBiGAxiKBcICCBAAGIAEGKIEwgIFEAAY7wXCAgUQIRigAcICBBAhGBWYAwCIBgGQBgiSBwgyLjEuMTYuM6AHzWayBwgwLjEuMTYuM7gHsyfCBwY1LjEyLjXIBy2ACAA&sclient=gws-wiz-serp


enum DEVICESTATE {
    S_BOOT,
    S_PENDING_WIFI,
    S_TCP_RECONNECT,
    S_TCP_PENDING_CONNECT,
    S_TCP_CONNECTED
};

//version control and capture of some system defaults for new compilations
///note, IP addresses are stored as a string to allow more easy editing in a web window or serial
struct CONTROLLER
{
    long softwareVersion = 20260406;  //yyyymmdd captured as an integer
    char AP_SSID[21] = "ESP_ACC";   //local SSID
    char AP_pwd[21] = "";
    char AP_IP[17] = "192.168.6.1\0";   //note the actual setting requires comma separators
    char STA_SSID[21] = "OSSONET\0";  //SSID when running as a station on an external WiFi network
    char STA_pwd[21] = "11223344AA\0";			//pwd for station
    char tcpIP[17] = "192.168.1.118\0";   //target IP of CONTROLLER to connect to
    uint16_t tcpPort = 1234;       //tcp port
    bool isDirty = false;  //will be true if EEPROM needs to be written
};



static uint8_t devicestate = S_BOOT;
CONTROLLER bootController;
IPAddress TCPserverIP;
AsyncClient* client = NULL;

unsigned long previousMillis;
unsigned long interval;
bool ledState = true;

static os_timer_t intervalTimer;
static os_timer_t watchdogTimer;
#define WATCHDOG_TIMEOUT 120000  //two minutes
#define LED_PIN 16

// Define Function Prototypes that use User Types below here or use a .h file
//


// Define Functions below here or use other .ino or cpp files
//


/*Design notes
The ESP will join a WiFi network and connect to a LocoNet TCP server running JRMI
It will respond to Loconet commands for turnouts and for Multi Aspect Signals
It will also respond to sensor polls and report changes in sensor state.

Because MAS are complex and often interworked with sensors and automation, it makes sense that JRMI is used for that, rather
than this unit connecting in a standalone mode with my ESP DCC controller.

The commands come in over plain TCP, there is no need to set up websockets.
in ESP command station, it is WiThrottle that sets up a TCP server, and then events are spawned from this.
We need a TCP client here.
https://www.google.com/search?q=ESP8266WiFi+act+as+tcp+client&rlz=1C1CHBF_enAU1138AU1138&oq=ESP8266WiFi+act+as+tcp+client&gs_lcrp=EgZjaHJvbWUyBggAEEUYOTIHCAEQIRigATIHCAIQIRigATIHCAMQIRigATIHCAQQIRigAdIBCTEzMjc4ajBqN6gCALACAA&sourceid=chrome&ie=UTF-8
ESP8266wifi has a built-in blocking tcp client, can use this.  Alternatively ESPAsyncTCP should support a client


*/



void onData(void* arg, AsyncClient* c, void* data, size_t len) {
    Serial.printf("Data received: %s\n", (char*)data);
    delay(500);
    c->write("RECEIVE B2 00 70 3D\n", 20);
}

void onConnect(void* arg, AsyncClient* c) {
    Serial.println("Connected to server");
    c->write("Hello from ESP12", 16); // Send data
}

void onError(void* arg, AsyncClient* c, int8_t error) {
    Serial.printf("Error: %d\n", error);
}

void onDisconnect(void* arg, AsyncClient* c) {
    Serial.println("Disconnected");
    client = NULL;
    delete c;  //prevents memory leaks
}

//called every 5 sec from intervalTimer
//it sends an ESPACC message as heartbeat but also to identify this device
static void replyToServer(void* arg) {
    AsyncClient* client = reinterpret_cast<AsyncClient*>(arg);

    // send reply to server
    if (client->space() > 32 && client->canSend()) {
        char message[32];
        
        snprintf(message, 32, "ESPACC");
        
        client->add(message, strlen(message));
        client->send();
    }
}



static void handleData(void* arg, AsyncClient* client, void* data, size_t len) {
    Serial.printf("\n%d bytes from server %s \n", len, client->remoteIP().toString().c_str());
    Serial.write((uint8_t*)data, len);  //write the bytes as received

}


#define TRACE

#ifndef TRACE
#define trace(traceCodeBlock) ;
#else
#define trace(traceCodeBlock) traceCodeBlock
#endif



// The setup() function runs once each time the micro-controller starts
void setup()
{
    devicestate = S_BOOT;
    
    //get settings from bootcontroller, 
    //connect to wifi
    //establish websocket connection... what if server is not there?  or we disco, we need to keep retrying.  maybe need a state engine
      

    Serial.begin(115200);
    delay(10);
    Serial.println('\n');


    WiFi.mode(WIFI_STA);
    WiFi.setHostname("ESPACC");

    Serial.println(F("For help use ?"));
    Serial.printf("Connecting to Wifi %s", bootController.STA_SSID);

    long dotTimer = millis();

    os_timer_disarm(&watchdogTimer);

    while (WiFi.status() != WL_CONNECTED) {
        checkSerial();
        if (millis() - dotTimer >= 500) {
            Serial.print('.');
            dotTimer = millis();
        }
    }
    //want the ESP to auto reconnect the WiFi if it fails
    WiFi.setAutoReconnect(true);

    Serial.print("Wifi Connected, IP address: ");
    Serial.println(WiFi.localIP().toString());
//    bootTCP();





    /*
    // Connect to Wi-Fi
    WiFi.begin(ssid, password);
    Serial.print("Connecting to ");
    Serial.print(ssid);

    // Wait for connection
    while (WiFi.status() != WL_CONNECTED) {
        delay(500);
        Serial.print(".");
    }

    Serial.println("");
    Serial.println("WiFi connected");
    Serial.print("IP address: ");
    Serial.println(WiFi.localIP()); // Prints ESP-12 IP address
    */

    // Create new client
    client = new AsyncClient();
    if (!client) return;

    // Attach callbacks
    client->onConnect(&onConnect, NULL);
    client->onError(&onError, NULL);
    client->onDisconnect(&onDisconnect, NULL);
    client->onData(&onData, NULL);

    // Connect to server
    client->connect(bootController.tcpIP, bootController.tcpPort);

    //Need a STATE ENGINE to ensure we reconnect to Wifi (if this is not auto) and to reconnect the LocoNet TCP link.

}

// Add the main program code into the continuous loop() function
void loop()
{
    //Wifi and TCP state engine

    unsigned long currentMillis = millis();
    //Wifi and TCP connection state engine
    switch (devicestate) {
    case S_BOOT:
        //do nothing the Wifi should auto reconnect
        if (WiFi.status() == WL_CONNECTED) devicestate = S_TCP_RECONNECT;
        break;


    case S_TCP_CONNECTED:
        //flash led 0.2 sec on, 5 off
        if (currentMillis - previousMillis >= interval) {
            digitalWrite(LED_PIN, ledState);  //led is active low, false=on
            interval = ledState ? 5000 : 200;
            ledState = !ledState;
            previousMillis = currentMillis;
        }
        break;

    case S_TCP_RECONNECT:
        //is Wifi still connected?
        if (WiFi.status() != WL_CONNECTED) {
            devicestate = S_BOOT;
            break;
        }

        bootTCP();
        devicestate = S_TCP_PENDING_CONNECT;
        break;

    case S_TCP_PENDING_CONNECT:
        //we kicked off ONE new attempt at a connect
        //flash led 1 sec on/off
        if (currentMillis - previousMillis >= 1000) {
            digitalWrite(16, ledState);
            ledState = !ledState;
            previousMillis = currentMillis;

            //NOTE: this technique of only allowing one pending connect at a time seems to work.  The asyncTCP object does have a timeout on it, and will call disconnect
            //after about 60 sec.  At this point we will retry the connection.
            //There is a risk that old instances of the client remain in memory and after about 30 instances are created the ESP will run out of resources and crassh, i.e. 
            //its a memory leak.

        }
        break;

    }





}


void checkSerial() {
    return;
}

void stringIPtoArray(char* s, uint8_t* myIP) {
    //IPAddress class requires the address to be provided as 4 octets
    //uint8_t myIP[4];
    char* p = nullptr;
    char ipBoot[17];
    strcpy(ipBoot, s);

    //strtok modifies its arguement, have to use a copy.
    p = strtok((char*)ipBoot, ",.");
    int i = 0;
    while (p != NULL) {
        myIP[i] = atoi(p);
        i++;
        if (i == 4) break;
        //more data?
        p = strtok(NULL, ",.");
    }
    return;
}

void bootTCP() {
    uint8_t myIP[4];
    stringIPtoArray(bootController.tcpIP, myIP);
    TCPserverIP = IPAddress(myIP);

  

    Serial.printf("Attempt connect to TCP server %s on port %d\n", TCPserverIP.toString().c_str(), bootController.tcpPort);

    AsyncClient* client = new AsyncClient;
    client->onData(&handleData, client);
    client->onConnect(&onConnect, client);

    //client->onError(&onError, client);
    client->onDisconnect(&onDisconnect, client);

    client->connect(TCPserverIP, bootController.tcpPort);

    //does it reconnect automatically? NO.  You need to destroy object by setting a nullptr;
    //onDisconnect, then you can open a new client which will sit and wait for the server to reappear


    os_timer_disarm(&intervalTimer);
    os_timer_setfn(&intervalTimer, &replyToServer, client);
    //this timer is not triggered yet, see on_timer_arm()
    //make sense as there is no point arming it until we are connected
}


void eeGetSettings(void) {
    CONTROLLER defaultController;  //grab defaults as per DCCcore.h
    EEPROM.begin(1024);
    int eeAddr = 0;
    EEPROM.get(eeAddr, bootController);
    if (defaultController.softwareVersion != bootController.softwareVersion) {
        /*need to re-initiatise eeprom with factory defaults*/
        EEPROM.put(0, defaultController);
        eeAddr += sizeof(bootController);
        EEPROM.commit();

        //Now populate our structs with EEprom values
        eeAddr = 0;
        EEPROM.get(eeAddr, bootController);
        eeAddr += sizeof(bootController);
    }

}

/// <summary>
/// save settings to EEPROM, we save the bootController struct
/// </summary>
void eePutSettings(void) {
    if (bootController.isDirty == false) { return; }
    int eeAddr = 0;
    EEPROM.put(eeAddr, bootController);
    eeAddr += sizeof(bootController);
    EEPROM.commit();
    bootController.isDirty = false;
    //trace(Serial.printf("EEPROM commit, bytes %d\r\n", eeAddr);)
}

/*
In Panel Pro, you create a sensor and have it query address 2, then we see a loconet transmission
RECEIVE B2 00 60 2D   which is odd, as I expected a SEND message.

if you command a turnout from PP [B0 01 00 4E]  Requesting Switch at LT2 to Thrown (Output Off).
we see Data received: RECEIVE B0 01 00 4E

But that's with the ESPcontroller connected, and remember that it is processing messages, so does that mean the PP Loconet server on 1234 only processes
messages inbound to the laptop (from controller) and rebroadcasts these, rather than the command that originated from the laptop?

And can I send a loconet message back into the system?

Because this means that if the ESPcontroller receives all the loconet commands, then I need it to act as a websocket broadcaster to my accessory device.


It does work.
Hercules TCP client connects on 192.168.1.118:1234  (loconet server on laptop)
SEND B2 00 70 3D<LF>  sent from Hercules
results in
Data received: RECEIVE B2 00 70 3D  on this client
and loconet monitor says
[B2 00 70 3D]  Sensor LS2 (AR2) is High
and this is reflected in the actual sensor table

BUT, I think the problem is this.  You can SEND a request to the laptop (eg from Hercules) but this is relayed out to the ESPcontroller for processing
and similarly asking to change a turnout in PP is sent to the ESPcontroller, and only appears as a receive message at Hercules.

So, we really do need to have the ESPcontroller talk to the accessory device, because the Laptop won't be directing the SEND requests to the accessory device
Also we can't use the port 1234 as a generic traffic path, as it will only pass on well formed loconet messages.

Now we do have a separate websocket port on the ESPcontroller, but how many clients can it support? 5 tops.   But in this JMRI set up arrangement, the ESP is not supporting
WiThrottle clients directly.


*/